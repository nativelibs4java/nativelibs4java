__kernel void test_local(__global uint4* seeds, __local float* floats)
{
}
